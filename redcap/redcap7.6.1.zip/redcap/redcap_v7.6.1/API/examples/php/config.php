<?php

$GLOBALS['super_api_token'] = 'ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234';
$GLOBALS['api_token']       = '12340DCA87C567B6FAAC8147AD7E4790';
$GLOBALS['api_url']         = 'http://example.com/redcap/api/';
