<?php

class FhirEhr
{	
	// Params for Open Epic (for demo purposes)
	private $openEpicLaunchUrl = 'https://open-ic.epic.com/Argonaut/api/Argonaut/2015/Argonaut/FHIR/LAUNCH/LaunchToken';
	private $openEpicPatient = 'ToHDIzZiIn5MNomO309q0f7TCmnOq6fbqOAWQHA1FRjkB'; // Open Epic test patient "James Kirk"
	// Other FHIR-related settings
	private $fhirState;
	private $fhirScope = 'patient/*.read offline_access'; // Need offline_access in order to obtain refresh_token
	private $fhirRedirectPage = 'ehr.php';
	private $ehrUser = null; // Capture (if possible) the EHR username during EHR launch
	private $ehrUIID = null;
	public  $fhirPatient = null; // Current patient
	public  $fhirAccessToken = null; // Current FHIR access token
	private $fhirServices = null;
	private $fhirPatientRecord = null; // Current patient's record name when in project context
	private $registeredProjects = array();
	private $unregisteredProjects = array();
	private $fhirDataConditions = "";
	private $fhirDataMeds = "";
	// Is the FHIR access token tied to a patient? Value of global $fhir_ehr_type will be checked against this.
	private $tokenPatientIndependentEHRs = array('epic');	
	// Map the FHIR endpoint category to the name of the date attribute in the resulting FHIR data bundle.
	// Note: The 'Patient' and 'CarePlan' categories do not have a date component.
	private $fhirEndpointDateAttribute = array(
		// FHIR endpoint => date attribute
		'Observation' => 'effectiveDateTime',
		'Condition' => 'dateRecorded', // or 'onsetDateTime'
		'MedicationOrder' => 'dateWritten',
		'AllergyIntolerance' => 'recordedDate', // or 'onset'
		'FamilyMemberHistory' => 'date',
		'DiagnosticReport' => 'effectiveDateTime', // or 'issued'
		'Immunization' => 'date',
		'Procedure' => 'performedDateTime',
		'Device' => 'expiry',
		'DocumentReference' => 'created' // or 'indexed'
	);	
	// Map the FHIR endpoint category to the name of the "code" sub-structure in the resulting FHIR data bundle.
	// Note: The 'Patient' and 'CarePlan' categories do not have this structure.
	private $fhirDataResourceCodeStructureName = array(
		// FHIR endpoint => attribute name in FHIR data
		'Observation' => 'code',
		'Condition' => 'code',
		'MedicationOrder' => 'dosageInstruction->route',
		'AllergyIntolerance' => 'substance',
		'FamilyMemberHistory' => 'relationship',
		'DiagnosticReport' => 'identifier->type',
		'Immunization' => 'vaccineCode',
		'Procedure' => 'code',
		'Device' => 'type',
		'DocumentReference' => 'class'
	);
	// Map the FHIR endpoint category to the name of the query string "date" parameter to limit the request's time period.
	// Note: The 'Patient', 'Device', and 'FamilyMemberHistory' categories do not have this structure.
	public static $fhirEndpointQueryStringDateParameter = array(
		// FHIR endpoint => date parameter name using in query string of FHIR request
		'Observation' => 'date', // or 'issued'
		'Condition' => 'onset',
		'MedicationOrder' => 'dateWritten',
		'AllergyIntolerance' => 'onset',
		'DiagnosticReport' => 'date',
		'Immunization' => 'date',
		'Procedure' => 'date',
		'CarePlan' => 'date',
		'DocumentReference' => 'created'
	);
	// Map the FHIR endpoint category to the name of the query string "code" parameter.
	// Note: Most categories do not have this structure.
	public static $fhirEndpointQueryStringCodeParameter = array(
		// FHIR endpoint => date parameter name using in query string of FHIR request
		'Observation' => 'code', // or 'category', Vitals as 'category=vital-signs'
		'Condition' => 'category' // or 'clinicalStatus', Problem List as 'category=problem,complaint,symptom,finding,diagnosis,health-concern' http://argonautwiki.hl7.org/index.php?title=Problems_and_Health_Concerns
	);
	
	// Construct
    public function __construct()
    {
		// Start the session if not started
		if (!session_id()) session_start();
		// Set FHIR state
		$this->fhirState = session_id();
		// Initialization check to ensure we have all we need
		$this->initCheck();
    }
	
	// Obtain the UI_ID from the most recently generated FHIR access token
	private function getUiIdRecentAccessToken()
	{
		$sql = "select token_owner from redcap_ehr_access_tokens order by expiration desc limit 1";
		$q = db_query($sql);
		return (db_num_rows($q) > 0) ? db_result($q, 0) : null;
	}
	
	// Set UI_ID contant (if not set)
	public function setUiId()
	{
		if (isset($this->ehrUIID) && is_numeric($this->ehrUIID)) return true;
		// Determine UI_ID from the username
		if (defined("USERID")) {
			$this->ehrUIID = User::getUIIDByUsername(USERID);
		}
		// The cron will not have a user session or have USERID set, so set it manually to the last user 
		// that had an active token (this is not ideal, but the best option available).
		if (defined("CRON")) {
			$this->ehrUIID = $this->getUiIdRecentAccessToken();
		}
		// Set UI_ID (but not for cron jobs)
		if (!defined("UI_ID") && !defined("CRON") && is_numeric($this->ehrUIID)) {
			define("UI_ID", $this->ehrUIID);
		}
		// Return boolean on if UI_ID is valid
		return is_numeric($this->ehrUIID);
	}
	
	// Set username constant
	public function setUserId()
	{
		if (!isset($_SESSION['username'])) return;
		defined("USERID") or define("USERID", strtolower($_SESSION['username']));
	}
	
	// Return variable name of field having MRN data type
	private function getFieldWithMrnValidationType()
	{
		global $Proj;
		$mrnValTypes = $this->getMrnValidationTypes();
		foreach ($Proj->metadata as $field=>$attr) {
			if ($attr['element_validation_type'] == '') continue;
			if (!isset($mrnValTypes[$attr['element_validation_type']])) continue;
			return $field;
		}
		return false;
	}
	
	// Return array of field validation types with MRN data type
	private function getMrnValidationTypes()
	{
		$mrnValTypes = array();
		$valTypes = getValTypes();
		foreach ($valTypes as $valType=>$attr) {
			if ($attr['data_type'] != 'mrn') continue;
			$mrnValTypes[$valType] = $attr['validation_label'];
		}
		return $mrnValTypes;
	}
	
	// Return the form_name and event_id of the DDP MRN field or the MRN data type field in the current project (if multiple, then return first)
	private function getFormEventOfMrnField()
	{
		global $Proj;
		// If DDP is enabled, then get DDP mapped MRN field
		$DDP = new DynamicDataPull($Proj->project_id, $Proj->project['realtime_webservice_type']);
		if ($DDP->isEnabledInSystem() && $DDP->isEnabledInProject()) {
			list ($field, $event_id) = $DDP->getMappedIdRedcapFieldEvent();
		} else {
			$field = $this->getFieldWithMrnValidationType();
			$event_id = $this->getFirstEventForField($field);
		}
		return array($field, $event_id);
	}
	
	// Return the event_id where a field's form_name is first used in a project
	private function getFirstEventForField($field)
	{
		global $Proj;
		// Get field's form
		$form = $Proj->metadata[$field]['form_name'];
		// Loop through events to find first event to which this form is designated
		foreach ($Proj->eventsForms as $event_id=>$forms) {
			if (!in_array($form, $forms)) continue;
			return $event_id;
		}
		return $Proj->firstEventId;
	}
	
	// Create new record for patient in project
	private function createNewPatientRecord($newRecord, $mrn)
	{
		global $Proj;
		// Find the form and event where the MRN field is located
		list ($mrnField, $mrnEventId) = $this->getFormEventOfMrnField();
		// Make sure record doesn't already exist
		if (Records::recordExists($newRecord)) exit("ERROR: Record \"$newRecord\" already exists in the project. Please try another record name.");
		// Add record as 2 data points: 1) record ID field value, and 2) MRN field value
		$sql = "insert into redcap_data (project_id, event_id, record, field_name, value) values
				(".PROJECT_ID.", $mrnEventId, '".db_escape($newRecord)."', '".db_escape($Proj->table_pk)."', '".db_escape($newRecord)."'),
				(".PROJECT_ID.", $mrnEventId, '".db_escape($newRecord)."', '".db_escape($mrnField)."', '".db_escape($mrn)."')";
		$q = db_query($sql);
		if ($q) {
			// Logging
			defined("USERID") or define("USERID", strtolower($_SESSION['username']));
			Logging::logEvent($sql, "redcap_data", "INSERT", $newRecord, "{$Proj->table_pk} = '$newRecord',\n$mrnField = '$mrn'", "Create record");
		}
		// Return boolean for success
		return $q;
	}
	
	// Perform FHIR launch via EHR
	public function launchFromEhr()
	{
		global $lang;
		// Instantiate FHIR Services
		$this->fhirServices = new FhirServices($this->getFhirEndpointBaseUrl(), $GLOBALS['fhir_client_id'], $GLOBALS['fhir_client_secret']);		
		// If using Public/None authentication for testing, manually set UI_ID constant
		$this->setUiId();
		// Development only: Perform an Open Epic auto-launch (simulates launch from EHR)
		if (isDev() && isset($_GET['open_epic_launch'])) {
			$this->renderDemoLaunchPage();
		}
		// CREATE NEW RECORD VIA EHR PORTAL
		elseif (isset($_SESSION['username']) && defined("PROJECT_ID") && isset($_POST['action']) && $_POST['action'] == 'create_record')
		{
			// Include
			require_once APP_PATH_DOCROOT . 'ProjectGeneral/form_renderer_functions.php';
			// Get record and MRN values
			$newRecord = $GLOBALS['auto_inc_set'] ? getAutoId() : $_POST['record'];
			if ($newRecord == '' || $_POST['mrn'] == '') exit("ERROR");
			// Create new record for patient in project
			if ($this->createNewPatientRecord($newRecord, $_POST['mrn'])) {				
				global $Proj;
				// If DDP-FHIR is enabled in the project, then go ahead and trigger DDP to start importing data
				if ($Proj->project['realtime_webservice_enabled'] && $Proj->project['realtime_webservice_type'] == 'FHIR') 
				{
					// Fetch DDP data from EHR
					$DDP = new DynamicDataPull($Proj->project_id, $Proj->project['realtime_webservice_type']);
					list($itemsToAdjudicate, $html) = $DDP->fetchAndOutputData($newRecord, null, array(), $Proj->project['realtime_webservice_offset_days'], 
													  $Proj->project['realtime_webservice_offset_plusminus'], false);
				}
				// Text to display in the dialog
				print $lang['data_entry_384'];
				// Also add hidden field as the new record name value
				print RCView::hidden(array('id'=>'newRecordCreated', 'value'=>$newRecord));
				// Add note about how many DDP items there are to adjudicate (if any)
				if (isset($itemsToAdjudicate) && $itemsToAdjudicate > 0) {
					print 	RCView::div(array('style'=>'color:#C00000;margin-top: 10px;'),
								RCView::span(array('class'=>'badge'), $itemsToAdjudicate) . 
								$lang['data_entry_378']
							);
				}
			} else {
				exit("ERROR: There was an error creating a new record.");
			}
		}
		// ALREADY LOGGED IN
		elseif (isset($_SESSION['username']) && $this->initSessionVars() && !isset($_GET['launch']) && !isset($_GET['code']) && !isset($_GET['error'])) 
		{
			// Display page with EHR user and patient in context
			$this->renderFhirPortal();
		}
		// AUTHORIZATION
		elseif (isset($_GET['launch']) && !isset($_GET['code']) && !isset($_GET['error']))
		{
			$this->fhirAuthorization($_GET['launch']);
		}
		// REQUEST ACCESS TOKEN & GET CLINICAL DATA
		elseif (isset($_GET['code']) && isset($_GET['state']) && !isset($_GET['error']))
		{
			// Validate the state if we haven't authenticated with REDCap yet
			if ($_GET['state'] != $this->fhirState && !isset($_SESSION['username'])) {
				throw new Exception("The 'state' parameter is incorrect!");
			}
			// Capture EHR user and add it to session and db table if "user" param is in launch query string
			$this->checkEhrUsername();
			// Check and update ISS value
			$this->checkEhrIss();
			// Acquire the FHIR access token from the server's token endpoint
			$tokenInfo = $this->acquireFhirAccessToken();
			// Add patient's access token to db table for later usage
			$this->storeAccessToken($tokenInfo);
			$this->setSessionVars($tokenInfo);
			// Now that session is active, redirect back to page with no query params
			redirect($_SERVER['PHP_SELF']);
		}
		// ERRORS
		elseif (isset($_GET['error'])) {
			throw new Exception(implode("; ", $_GET));
		} else {
			throw new Exception("This application can only be accessed from inside the EHR system. If your REDCap session timed out, you will need to relaunch from within the EHR system.");
		}
	}
	
	// Set session variables (EHR user, patient, access token)
	private function setSessionVars($tokenInfo)
	{
		$this->fhirPatient = $_SESSION['ehr-fhir']['fhirPatient'] = $tokenInfo->patient;
		$this->fhirAccessToken = $_SESSION['ehr-fhir']['fhirAccessToken'] = $tokenInfo->access_token;
		$_SESSION['ehr-fhir']['ehrUser'] = $this->ehrUser;
	}
	
	// Initialize session variables as object varables (EHR user, patient, access token)
	private function initSessionVars()
	{
		// Check for session variables
		if (!isset($_SESSION['ehr-fhir']) || !is_array($_SESSION['ehr-fhir']) || empty($_SESSION['ehr-fhir']['ehrUser'])) return false;
		$this->fhirPatient = $_SESSION['ehr-fhir']['fhirPatient'];
		$this->fhirAccessToken = $_SESSION['ehr-fhir']['fhirAccessToken'];
		$this->ehrUser = $_SESSION['ehr-fhir']['ehrUser'];		
		// Set username constant
		$this->setUserId();
		$this->setUiId();
		return true;
	}
	
	// If there is an institution-specific MRN, then store in access token table to pair it with the patient id
	private function storePatientMrn($patient, $mrn=null)
	{
		$sql = "update redcap_ehr_access_tokens set mrn = ".checkNull($mrn)." 
				where patient = '".db_escape($patient)."'";
		return db_query($sql);
	}
	
	// If there is an institution-specific MRN, then use it to return the patient id
	public function getPatientIdFromMrn($mrn=null)
	{
		$sql = "select patient from redcap_ehr_access_tokens where mrn = ".checkNull($mrn)." limit 1";
		$q = db_query($sql);
		if ($q && db_num_rows($q) > 0) return db_result($q, 0);
		// Not currently in db table, so attempt to find using Patient FHIR service search
		return $this->getPatientIdFromMrnWebService($mrn);
	}
	
	// Display page with EHR user and patient in context
	private function renderFhirPortal()
	{
		global $lang;
		// Retrieve basic patient demography data via FHIR
		if (!$_SESSION['ehr-fhir']['patientInfo'] || empty($_SESSION['ehr-fhir']['patientInfo'])) 
		{
			// FHIR request
			$patientData = $this->fhirServices->getPatientDemographics($this->fhirAccessToken, $this->fhirPatient);			
			if (!isset($patientData->id) || empty($patientData->id)) {
				throw new Exception("The patient's demography data could not be retrieved from the EHR system.");
			}
			// Store current patient's name, MRN, and DOB in session
			$_SESSION['ehr-fhir']['patientInfo']['fhirPatientFirstName'] = $patientData->name[0]->given[0];
			$_SESSION['ehr-fhir']['patientInfo']['fhirPatientLastName'] = $patientData->name[0]->family[0];
			$_SESSION['ehr-fhir']['patientInfo']['fhirPatientBirthDate'] = $patientData->birthDate;
			// Get institution-specific MRN
			$institutionMrn = $this->fhirServices->getPatientMrn($patientData, $GLOBALS['fhir_ehr_mrn_identifier']);
			$_SESSION['ehr-fhir']['patientInfo']['fhirPatientMRN'] = $institutionMrn ? $institutionMrn : $this->fhirPatient;
			// If there is an institution-specific MRN, then store in access token table to pair it with the patient id
			if ($institutionMrn) {
				$this->storePatientMrn($this->fhirPatient, $institutionMrn);
			}
		}
		
		// Add/remove project from Registered Project list
		$this->checkAddRemoveProject();
		
		// Get array of MRN field validation types
		$mrnValidationTypes = $this->getMrnValidationTypes();
		
		// Create arrays of registered and unregistered projects for the current user
		$this->setRegisteredProjects();
		$this->setUnegisteredProjects();
		
		$unregisteredProjectsDropdown = RCView::select(array('id'=>'unregisteredProjects', 'class'=>'x-form-text x-form-field', 'style'=>'max-width:400px;', 'onchange'=>"window.location.href=app_path_webroot+'ehr.php?addProject='+this.value;"), 
										array(''=>'-- '.$lang['data_entry_373'].' --')+$this->unregisteredProjects, '', 500);
		
		// Render page and navbar
		$HtmlPage = new HtmlPage();
		$HtmlPage->PrintHeaderExt();
		$this->renderNavBar();
		
		?>
		<style type="text/css">
		#pagecontainer { max-width:100%; }
		</style>
		<?php
		
		// Project NOT selected yet, so display project list
		print "<div class='container-fluid' style='margin-top:40px;'>";
										
		// Build project list table
		$class = 'even';
		$tableRows = '';			
		$tableHdr = RCView::tr('', RCView::th(array('style'=>'background-color: #ddd;border: 1px solid #bbb;'), 
						RCView::div(array('class'=>'pull-left', 'style'=>'font-size:16px;'),
							$lang['data_entry_389']
						) .
						RCView::div(array('class'=>'pull-right', 'style'=>'font-weight:normal;'),
							$unregisteredProjectsDropdown
						)
					));	
		foreach ($this->registeredProjects as $this_project_id=>$attr)
		{
			$class = ($class == 'odd') ? 'even' : 'odd';
			$rowHtml = "";
			if ($attr['has_mrn_field_type'] || $attr['ddp_enabled']) {
				$ddpMsg = "";
				if ($attr['record'] == '') {
					// Disable button if user doesn't have Create Record privileges in the project
					$buttonDisabled = $attr['record_create'] ? '' : 'disabled';
					$buttonTitle = $attr['record_create'] ? $lang['data_entry_376'] : $lang['data_entry_394'];
					// Patient record doesn't exist in project
					$button = RCView::button(array('class'=>'btn btn-success btn-xs', 'title'=>$buttonTitle, $buttonDisabled=>$buttonDisabled, 'onclick'=>"addPatientToProject($this_project_id,'".htmlspecialchars( $_SESSION['ehr-fhir']['patientInfo']['fhirPatientMRN'], ENT_QUOTES)."','{$attr['record_auto_numbering']}')"), 
								RCView::span(array('class'=>'glyphicon glyphicon-plus'), '') . RCView::SP . $lang['data_entry_376']
							  );
				} else {
					// Patient is in project
					$button = RCView::button(array('class'=>'btn btn-primary btn-xs', 'onclick'=>"window.location.href=app_path_webroot+'DataEntry/record_home.php?pid=$this_project_id&id={$attr['record']}'"), 
								RCView::img(array('src'=>'application_view_tile.png')) . " " .
								$lang['data_entry_377']
							  );
				}
				if ($attr['ddp_items'] != '') {
					// Patient record doesn't exist in project
					$ddpMsgSub = ($attr['ddp_items'] == '0') ? $lang['data_entry_379'] : 
						RCView::a(array('href'=>APP_PATH_WEBROOT."DataEntry/record_home.php?pid=$this_project_id&id={$attr['record']}&openDDP=1", 'style'=>'color:#C00000;'), 
							RCView::span(array('class'=>'badge'), $attr['ddp_items']) . $lang['data_entry_378']
						);
					$ddpMsg = RCView::div(array('style'=>'display:inline-block;'), $ddpMsgSub);
				}
				$rowHtml .= RCView::div(array('class'=>'pull-left', 'style'=>'width:180px;'),
								$button
							) .
							RCView::div(array('class'=>'pull-left'),
								RCView::div(array('class'=>"ehr-project-title-$this_project_id", 'style'=>'font-size:14px;font-weight:600;'), $attr['app_title']) .
								RCView::div(array('style'=>'margin-top:1px;margin-left: -4px;'), $ddpMsg)
							);
			} else {
				$rowHtml .= RCView::div(array('class'=>'pull-left', 'style'=>'width:180px;'),
								RCView::span(array('style'=>'font-size:12px;color:#999;padding:10px;'), $lang['data_entry_380'])
							) .
							RCView::div(array('class'=>'pull-left'),
								RCView::div(array('class'=>"ehr-project-title-$this_project_id", 'style'=>'font-size:14px;font-weight:600;'), $attr['app_title']) .
								RCView::div(array('style'=>'color:#A00000;font-size:12px;'), 
									($GLOBALS['realtime_webservice_global_enabled'] ? $lang['data_entry_393'] : $lang['data_entry_375'])
								)
							);
			}
			// Remove project
			$rowHtml .= RCView::div(array('class'=>'pull-right', 'style'=>''),
							RCView::a(array('class'=>'ehr-remove', 'href'=>APP_PATH_WEBROOT."ehr.php?removeProject=$this_project_id"), 
								$lang['data_entry_369']
							)
						);
			$tableRows .= RCView::tr(array('class'=>$class), RCView::td('', $rowHtml));				
		}
		// If no projects have been registered, display instructions
		if (empty($this->registeredProjects)) 
		{
			$rowHtml .= RCView::div(array('style'=>'font-weight:bold;color:#C00000;padding:10px 20px;'),
							$lang['data_entry_386']
						) .
						RCView::div(array('style'=>'color:#A00000;padding:10px 20px 0;'),
							$lang['data_entry_385'] . " " .
							($GLOBALS['realtime_webservice_global_enabled']
								? $lang['data_entry_392']
								: $lang['data_entry_391']
							) .
							" " . $lang['data_entry_387'] . " <b>" . implode("</b>, <b>", $mrnValidationTypes) . "</b>" .
							$lang['period']
						);
			$tableRows .= RCView::tr(array('class'=>'odd'), RCView::td('', $rowHtml));	
		}
		// Display table
		print 	RCView::div(array('class'=>'col-xs-12'),
					RCView::table(array('class'=>'dataTable cell-border no-footer', 'style'=>'width:800px;max-width:90%;'), 
						RCView::thead('', $tableHdr) .
						RCView::tbody('', $tableRows)
					)
				);
		print "</div>";
		// If no MRN field validations are enabled, then display warning message
		if (empty($mrnValidationTypes)) {
			print RCView::div(array('class'=>'red'), $lang['data_entry_388']);
		}
		// JavaScript file
		callJSfile('ehr.js');
		// Dialog div
		print 	RCView::div(array('id'=>'addPatientDialog', 'class'=>'simpleDialog', 'title'=>$lang['data_entry_402']." ".$lang['data_entry_376'].$lang['questionmark']),
					$lang['data_entry_382'] . " " .
					RCView::span(array('id'=>'newRecordNameAutoNumText'),
						$lang['data_entry_383']
					) .
					RCView::div(array('style'=>'margin-top:10px;'),
						RCView::b($lang['create_project_87']) . RCView::SP . RCView::SP . 
						RCView::span(array('id'=>'newRecordNameProjTitle', 'style'=>'color:#C00000;'), '')
					) .
					RCView::div(array('id'=>'newRecordNameDiv', 'style'=>'margin-top:10px;'),
						RCView::b($lang['data_entry_381']) . RCView::SP . RCView::SP . 
						RCView::text(array('id'=>'newRecordName', 'class'=>'x-form-text x-form-field'))
					)
				);		
		// Footer
		$HtmlPage->PrintFooterExt();
		exit;
	}
	
	// Render navbar
	public function renderNavBar()
	{
		global $lang;
		$projectTitle = "";
		if (defined("PROJECT_ID")) {
			$projectTitle = RCView::div(array('class'=>'clearfix', 'style'=>'font-size:14px;'),
								RCView::div(array('class'=>'pull-left', 'style'=>'width:100px;'),
									RCView::a(array('href'=>APP_PATH_WEBROOT.'ehr.php', 'style'=>'margin-left:5px;font-size:12px;text-decoration:underline;'), $lang['home_22'])
								) .
								RCView::div(array('class'=>'pull-left'),
									$lang['create_project_87'] . " " . 
									RCView::span(array('style'=>'font-weight:700;color:#C00000;'), strip_tags($GLOBALS['app_title']))
								)
							);
		}
		print 	"<nav class='navbar navbar-default navbar-fixed-top' style='margin-bottom:5px;min-height:25px;padding:4px 0;background-color:#eee;border-bottom:1px solid #ccc;'>" .
					RCView::div(array('class'=>'container-fluid', 'style'=>'padding:0 10px 0 5px;'),
						RCView::div(array('class'=>'navbar-collapse clearfix'),
							RCView::div(array('class'=>'pull-left', 'style'=>'font-size:14px;'),
								RCView::a(array('href'=>APP_PATH_WEBROOT.'ehr.php', 'style'=>'margin-right:25px;'),
									"<img src='".APP_PATH_IMAGES."redcap-logo-small.png' style='height:22px;'>"
								) .
								(($_SESSION['ehr-fhir']['patientInfo']['fhirPatientMRN'] != $_SESSION['ehr-fhir']['fhirPatient'])
									? "MRN ".RCView::span(array('style'=>'color:#C00000;'), $_SESSION['ehr-fhir']['patientInfo']['fhirPatientMRN']) 
									: "Patient ".RCView::span(array('style'=>'color:#C00000;'), $_SESSION['ehr-fhir']['fhirPatient'])) .
								" &ndash; <b>{$_SESSION['ehr-fhir']['patientInfo']['fhirPatientLastName']}, {$_SESSION['ehr-fhir']['patientInfo']['fhirPatientFirstName']}</b>
								(DOB {$_SESSION['ehr-fhir']['patientInfo']['fhirPatientBirthDate']})"
							) .				
							RCView::div(array('class'=>'pull-right', 'style'=>'font-size:12px;'),
								"Logged in as <b>".$_SESSION['ehr-fhir']['ehrUser']."</b> / <b>".USERID."</b>"
							)
						) .
						$projectTitle
					) .
				"</nav>";
	}
	
	// Add/remove project from Registered Project list, then redirect back to prev page.
	private function checkAddRemoveProject()
	{
		// Add
		if (isset($_GET['addProject']) && is_numeric($_GET['addProject'])) {
			$sql = "insert into redcap_ehr_user_projects (project_id, redcap_userid) values ('".db_escape($_GET['addProject'])."', ".UI_ID.")";
			if (db_query($sql)) redirect(APP_PATH_WEBROOT."ehr.php");
		}		
		// Remove
		elseif (isset($_GET['removeProject']) && is_numeric($_GET['removeProject'])) {
			$sql = "delete from redcap_ehr_user_projects where project_id = '".db_escape($_GET['removeProject'])."' and redcap_userid = ".UI_ID;
			if (db_query($sql)) redirect(APP_PATH_WEBROOT."ehr.php");
		}
	}		
	
	// Set and get the record name for patient in the current project
	private function setRecordName()
	{
		if (!isset($this->fhirPatient) || $this->fhirPatient == '') {
			throw new Exception("Could not find the patient's medical record number.");
		}
		// Use 'mrn' validation data type to find matching record in project
		$sql = "select d.record from redcap_validation_types v, redcap_metadata m, redcap_data d 
				where v.data_type = 'mrn' and m.project_id = ".PROJECT_ID." and m.element_validation_type = v.validation_name 
				and d.project_id = m.project_id and d.field_name = m.field_name and d.value = '".db_escape($this->fhirPatient)."'
				order by d.record limit 1";
		$q = db_query($sql);
		if (db_num_rows($q) < 1) {
			throw new Exception("Could not find the patient's record in the current project.");
		}
		// Set record name
		$this->fhirPatientRecord = db_result($q, 0);
	}
	
	// Acquire the FHIR access token from the server's token endpoint.
	// Also store the token for the record in the db table.
	// Returns the token object containing all the token's metadata.
	private function acquireFhirAccessToken()
	{
		// Make request to token endpoint URL to get access token
		$tokenInfo = $this->fhirServices->getAuthToken($_GET['code'], $this->getFhirRedirectUrl());
		if (!$tokenInfo) {
			throw new Exception("Failed to retrieve FHIR access token.");
		} elseif (isset($tokenInfo->error)) {
			throw new Exception(implode("; ", $tokenInfo));
		} elseif (!isset($tokenInfo->patient)) {
			throw new Exception("No patient context was found.");
		}
		// Return token object
		return $tokenInfo;
	}
	
	// Perform FHIR authorization
	private function fhirAuthorization($launchToken=null)
	{
		// This is the beginning of authorization, so wipe the FHIR session info
		$this->destroyFhirSessionData();
		// Capture EHR user and add it to session and db table if "user" param is in launch query string
		$this->getEhrUsernameFromUrl();
		// Capture EHR's base URL (ISS passed in query string) and use it later to update redcap_config after successful launch.
		$this->getEhrIss();
		// Set FHIR state
		$this->fhirState = session_id();
		// Get authorize URL
		$authorizeUrl = $this->fhirServices->getAuthorizeUrl($this->getFhirRedirectUrl(), $this->fhirScope, $this->fhirState, $launchToken);
		// Redirect user to authorize URL
		redirect($authorizeUrl);
	}
	
	// Destory FHIR session data and erase all cookies
	public function destroyFhirSessionData()
	{
		$_SESSION = array();
		session_unset();
		session_destroy();
		deletecookie('PHPSESSID');
		deletecookie('redcap_ehr_user');
		deletecookie('redcap_ehr_iss');
		// Start the session with a clean slate
		if (!session_id()) session_start();
		$_SESSION = array();
	}
	
	// Capture EHR's base URL (ISS passed in query string) and use it later to update redcap_config after successful launch.
	// This is used to correct the ISS stored in REDCap if was mistyped or incorrect originally.
	private function getEhrIss()
	{
		if (!(isset($_GET['iss']) && isset($_GET['launch']))) return;
		// Set username in object and session
		$iss = trim(rawurldecode(urldecode($_GET['iss'])));
		// Set encrypted session cookie
		savecookie('redcap_ehr_iss', encrypt($iss), 300);
	}
	
	// Check if the EHR's base URL (ISS) is different from stored in redcap_config. If so, then update it in redcap_config.
	private function checkEhrIss()
	{
		global $fhir_endpoint_base_url;
		if (!isset($_COOKIE['redcap_ehr_iss'])) return;
		$iss = decrypt($_COOKIE['redcap_ehr_iss']);
		if (empty($iss)) return;
		// Ensure the endpoint ends with a slash "/"		
		if (substr($iss, -1) != "/") $iss .= "/";
		// If a value ISS and different from config value, then update config
		if ($iss."" !== $fhir_endpoint_base_url."") {
			$sql = "update redcap_config set value = '".db_escape($iss)."' where field_name = 'fhir_endpoint_base_url'";
			db_query($sql);
		}
		// We no longer need the cookie
		deletecookie('redcap_ehr_iss');
	}
	
	// Capture EHR user and add it to session if "user" param is in launch query string
	private function getEhrUsernameFromUrl()
	{
		// For SMART Sandbox, auto-add user for testing purposes.
		if (strpos($this->getFhirEndpointBaseUrl(), 'smarthealthit.org')) {
			$_GET['user'] = 'SMART_FAKE_USER';
		}
		// For Open Epic, auto-add user for testing purposes.
		if (strpos($this->getFhirEndpointBaseUrl(), 'open-ic.epic.com')) {
			$_GET['user'] = 'OPEN_EPIC_FAKE_USER';
		}
		// Make sure we have the user in query string
		if (!isset($_GET['user']) && isset($_GET['launch'])) {
			$msg = "Could not verify identify of EHR user. The EHR should launch to ".$this->getFhirRedirectUrl()."?user=EHR_USERNAME,
					in which EHR_USERNAME should be the username of the EHR user. Make sure your EHR system has been configured to call
					REDCap and add the \"user\" parameter to the URL query string. For example, for Epic append ?user=%EPICUSERID% to the URL.";
			throw new Exception($msg);
		}
		// Set username in object and session
		$this->ehrUser = trim(rawurldecode(urldecode($_GET['user'])));
		// Set encrypted session cookie
		savecookie('redcap_ehr_user', encrypt($this->ehrUser), 300);
	}
	
	// Capture EHR user and add it to session and db table if "user" param is in launch query string
	private function checkEhrUsername()
	{
		// If we have EHR username in session from before authorization, set it now that we have successfully authorized
		if (isset($_COOKIE['redcap_ehr_user'])) {
			$this->ehrUser = decrypt($_COOKIE['redcap_ehr_user']);
			// If cookie decryption failed, then return error
			if (empty($this->ehrUser)) {
				throw new Exception("Could not verify identify of EHR user. The encrypted cookie value was incorrect.");
			}
		}
		// If username was passed from EHR, and we don't have a REDCap auth session yet, then show the REDCap login screen
		if (!empty($this->ehrUser) && !isset($_SESSION['username'])) {
			// See if this user is already mapped in the db table
			$redcapUsername = $this->getMappedUsernameFromEhrUser();
			if ($redcapUsername) {
				// Perform auto-login
				require_once dirname(dirname(__FILE__)) . '/Libraries/PEAR/Auth.php';
				Authentication::autoLogin($redcapUsername);
			}
		}
		if (!isset($_SESSION['username'])) {
			// If using Public/None authentication, then set username manually and bypass
			if ($GLOBALS['auth_meth_global'] == 'none') {
				$_SESSION['username'] = 'site_admin';
			}
			// Render REDCap login form
			else {
				loginFunction();
			}
		}
		if (isset($_SESSION['username'])) {
			// Add EHR username to map table
			$this->addEhrUserMap($_SESSION['username']);
			// Set username constant
			$this->setUserId();
			$this->setUiId();
			// Remove the cookie now that we don't need it
			deletecookie('redcap_ehr_user');
		} else {
			throw new Exception("Could not verify identify of EHR user. Make sure that \"?user=EHR_USERNAME\" is being passed in the REDCap URL by the EHR during the launch.");
		}
	}
	
	// Map REDCap username to EHR username in db table
	private function addEhrUserMap($redcapUsername)
	{
		// Get user info
		$row = User::getUserInfo($redcapUsername);
		$sql = "replace into redcap_ehr_user_map (ehr_username, redcap_userid) 
				values ('".db_escape($this->ehrUser)."', '".db_escape($row['ui_id'])."')";
		return db_query($sql);
	}	
	
	// Query table to get REDCap username from passed EHR username
	private function getMappedUsernameFromEhrUser()
	{		
		$sql = "select i.username from redcap_ehr_user_map m, redcap_user_information i
				where i.ui_id = m.redcap_userid and m.ehr_username = '".db_escape($this->ehrUser)."'";
		$q = db_query($sql);
		return (db_num_rows($q) ? db_result($q, 0) : false);
	}	
	
	// Query table to determine if REDCap username has been whitelisted for DDP on FHIR
	public function isDdpUserWhitelistedForFhir($username)
	{		
		$sql = "select 1 from redcap_ehr_user_map m, redcap_user_information i
				where i.ui_id = m.redcap_userid and i.username = '".db_escape($username)."'";
		$q = db_query($sql);
		return (db_num_rows($q) > 0);
	}
	
	// Obtain the FHIR redirect URL for this external module (assumes that page=index is the main launching page)
	private function getFhirRedirectUrl()
	{
		return APP_PATH_WEBROOT_FULL . $this->fhirRedirectPage;
	}
	
	// Obtain the FHIR service endpoint base URL
	public function getFhirEndpointBaseUrl()
	{
		// If we are launching and have launch and iss params, then override with iss param
		if (isset($_GET['launch']) && isset($_GET['iss'])) {
			$fhirEndpoint = rawurldecode(urldecode($_GET['iss']));
			// Ensure the endpoint ends with a slash "/"		
			if (substr($fhirEndpoint, -1) != "/") $fhirEndpoint .= "/";
			// Set and add endpoint to session
			$_SESSION['ehr-fhir']['fhir_endpoint_base_url'] = $fhirEndpoint;
		}
		// If endpoint is already stored in session, then use it
		elseif (isset($_SESSION['ehr-fhir']) && is_array($_SESSION['ehr-fhir']) && !empty($_SESSION['ehr-fhir']['fhir_endpoint_base_url'])) {
			return $_SESSION['ehr-fhir']['fhir_endpoint_base_url'];
		}
		// Get endpoint from module config. Also, add it to session to keep
		else {
			$fhirEndpoint = $GLOBALS['fhir_endpoint_base_url'];
			// Ensure the endpoint ends with a slash "/"		
			if (substr($fhirEndpoint, -1) != "/") $fhirEndpoint .= "/";
		}
		// Return the endpoint
		return $fhirEndpoint;
	}
	
	// Initialization check to ensure we have all we need
	private function initCheck()
	{
		$errors = array();
		if (empty($GLOBALS['fhir_client_id'])) {
			$errors[] = "Missing the FHIR client_id! Please add value to module configuration.";
		}
		if (empty($GLOBALS['fhir_endpoint_base_url'])) {
			$errors[] = "Missing the FHIR endpoint base URL! Please add value to module configuration.";
		}
		if (!empty($errors)) {
			throw new Exception("<br>- ".implode("<br>- ", $errors));
		}	
	}
	
	// Render a demo page that simulates an EHR launch using Open Epic website
	private function renderDemoLaunchPage()
	{
		// Ensure that our endpoint is open-ic.epic.com
		$this->checkOpenEpic();
		// Generate Open Epic launch token
		$launchToken = $this->retrieveOpenEpicLaunchToken();
		if (!$launchToken) throw new Exception("Not able to generate FHIR launch token from<br>" . $this->getOpenEpicLaunchTokenGeneratorUrl());
		// Output page
		$HtmlPage = new HtmlPage();
		$HtmlPage->PrintHeaderExt();
		?>
		<style type="text/css">
		body { 
			background: url('<?php print APP_PATH_IMAGES ?>ehr_demo_screenshot.png') no-repeat left top; 
			padding: 180px 0px 20px 130px;
		}
		#pagecontainer { max-width: 100%; }
		#ehr_iframe { display:none;width:100%;max-width:920px;height:500px;border:1px solid #ddd; }
		</style>
		<script type="text/javascript">
		$(function(){
			$('#launch_btn_div button').click(function(){
				// $('#launch_btn_div').hide();
				// $('#ehr_iframe').show().attr('src', '<?php print $this->getFhirRedirectUrl() . "?launch=" . urlencode($launchToken) . "&iss=" . urlencode($GLOBALS['fhir_endpoint_base_url']) ?>');
				window.location.href = '<?php print $this->getFhirRedirectUrl() . "?launch=" . urlencode($launchToken) . "&iss=" . urlencode($GLOBALS['fhir_endpoint_base_url']) ?>';
			});
		});
		</script>
		<div id="launch_btn_div">
			<button class="btn btn-primary">Launch REDCap</button>
		</div>
		<iframe id="ehr_iframe" src="<?php echo APP_PATH_WEBROOT ?>DataEntry/empty.php"></iframe>
		<?php
		$HtmlPage->PrintFooterExt();
	}
	
	// Verify that our FHIR endpoint URL is Open Epic. Return boolean.
	private function isOpenEpic()
	{
		return (!empty($GLOBALS['fhir_endpoint_base_url']) && strpos($GLOBALS['fhir_endpoint_base_url'], "open-ic.epic.com") !== false);
	}
	
	// Verify that our FHIR endpoint URL is Open Epic. If not, display error.
	private function checkOpenEpic()
	{
		if ($this->isOpenEpic()) return;
		$HtmlPage = new HtmlPage();
		$HtmlPage->PrintHeaderExt();
		print  "<div style='max-width:600px;'>
				<b>ERROR:</b> To use this EHR launch simulation page, you must have your FHIR Endpoint Base URL set to 
				<b>https://open-ic.epic.com/argonaut/api/FHIR/Argonaut/</b>, and you must have created an app at
				<a style='text-decoration:underline;' target='_blank' href='https://open.epic.com/MyApps'>https://open.epic.com/MyApps</a>. After creating an app,
				make sure that <b>".APP_PATH_WEBROOT_FULL."external_modules/index.php</b> is set as a Redirect URL, and that you obtain 
				the <u>NonProd</u> Client ID to enter for this module in the REDCap Control Center.
				Additionally, make sure the FHIR API Scope for this app on Open Epic includes the following: 
				<b>PATIENT.READ, PATIENT.SEARCH, OBSERVATION.READ, OBSERVATION.SEARCH, CONDITION.READ, CONDITION.SEARCH</b>.
				</div>";
		$HtmlPage->PrintFooterExt();
		exit;
	}
	
	// Build the Open Epic URL for generating a launch token
	private function getOpenEpicLaunchTokenGeneratorUrl()
	{
		return $this->openEpicLaunchUrl . "?patient=" . $this->openEpicPatient . "&client_id=" . $GLOBALS['fhir_client_id'];
	}
	
	// Retrieve the launch token from Open Epic (open.epic.com used to simulate an EHR launch)
	private function retrieveOpenEpicLaunchToken()
	{
		$url = $this->getOpenEpicLaunchTokenGeneratorUrl();
		$response = http_get($url, null, "", array('Accept: application/json'));
		$launch_info = json_decode($response);
		if (is_object($launch_info) && !empty($launch_info->launch)) {
			return $launch_info->launch;
		}
		return false;
	}
	
	// Add patient's access token to db table for later usage
	private function storeAccessToken($tokenInfo, $mrn=null)
	{
        if (!is_object($tokenInfo) || !isset($tokenInfo->access_token) || !isset($tokenInfo->patient)) {
            return false;
        }
		// Set expiration time of token
		$expiration = null;
		if (isset($tokenInfo->expires_in) && is_numeric($tokenInfo->expires_in)) {
			$expiration = date("Y-m-d H:i:s", mktime(date("H"),date("i"),date("s")+$tokenInfo->expires_in,date("m"),date("d"),date("Y")));
		}
		// Do we have a refresh token? If so, update table with it, else leave existing refresh token in table.
		$refresh_token = isset($tokenInfo->refresh_token) ? $tokenInfo->refresh_token : $this->getRefreshTokenByPatientId($tokenInfo->patient);
		// Add values to table
		$sql = "select 1 from redcap_ehr_access_tokens where patient = ".checkNull($tokenInfo->patient)."
				and token_owner = ".checkNull($this->ehrUIID);
		$q = db_query($sql);
		if (db_num_rows($q)) {
			// Update
			$sql = "update redcap_ehr_access_tokens set mrn = ".checkNull($mrn).", expiration = ".checkNull($expiration).", 
					access_token = ".checkNull($tokenInfo->access_token).", refresh_token = ".checkNull($refresh_token)."
					where patient = ".checkNull($tokenInfo->patient)." and token_owner = ".checkNull($this->ehrUIID);
		} else {
			// Insert
			$sql = "insert into redcap_ehr_access_tokens (patient, mrn, token_owner, expiration, access_token, refresh_token) values
					(".checkNull($tokenInfo->patient).", ".checkNull($mrn).", ".checkNull($this->ehrUIID).", ".checkNull($expiration).", 
					".checkNull($tokenInfo->access_token).", ".checkNull($refresh_token).")";
		}
		return db_query($sql);
	}
	
	// Use any access token and an MRN to obtain a patient id value
	public function getPatientIdFromMrnWebService($mrn=null)
	{
		if ($GLOBALS['fhir_ehr_mrn_identifier'] == '' || empty($mrn)) return false;
		// Get token
		$token = $this->getAccessToken();
		// Remove "urn:oid:" from beginning of identifier->system	
		$identifierSystem = str_replace("urn:oid:", "", $GLOBALS['fhir_ehr_mrn_identifier']); 
		$url = $this->getFhirEndpointBaseUrl() . "Patient?identifier=".urlencode("$identifierSystem|$mrn");
		// Instantiate FHIR Services
		$this->fhirServices = new FhirServices($this->getFhirEndpointBaseUrl(), $GLOBALS['fhir_client_id'], $GLOBALS['fhir_client_secret']);
		$data = $this->fhirServices->getPatientData($url, $token);
		if (!isset($data->resourceType) || $data->resourceType != 'Bundle' || $data->total != '1') return false;
		// Set patient id
		$patient_id = $data->entry[0]->resource->id;
		// Add to token table if not already stored so that we have the patient-mrn matched already on file
		$sql = "insert into redcap_ehr_access_tokens (patient, mrn, token_owner) 
				values ('".db_escape($patient_id)."', '".db_escape($mrn)."', '".db_escape($this->ehrUIID)."')";
		db_query($sql);
		// Return the patient id
		return $patient_id;		
	}
	
	
	// Obtain any patient's access token from db table
	public function getAnyAccessToken()
	{
		// Get value from table
		$sql = "select access_token from redcap_ehr_access_tokens  
				where (expiration is null or expiration > '".NOW."') and token_owner = '".db_escape($this->ehrUIID)."'
				order by expiration limit 1";
		$q = db_query($sql);
		return (db_num_rows($q) > 0) ? db_result($q, 0) : "";
	}
	
	// Obtain any patient's refresh token from db table
	public function getAnyRefreshToken()
	{
		// Get value from table
		$sql = "select refresh_token from redcap_ehr_access_tokens 
				where refresh_token is not null and token_owner = '".db_escape($this->ehrUIID)."'
				order by expiration limit 1";
		$q = db_query($sql);
		return (db_num_rows($q) > 0) ? db_result($q, 0) : "";
	}
	
	// Obtain a patient's access token from db table
	public function getAccessToken($patient=null)
	{
		// Make sure UI_ID is set
		$this->setUiId();
		if ($patient != '') {
			// Get value from table
			$sql = "select access_token from redcap_ehr_access_tokens  
					where (expiration is null or expiration > '".NOW."') 
					and access_token is not null and patient = '".db_escape($patient)."'
					and token_owner = '".db_escape($this->ehrUIID)."'";
			$q = db_query($sql);
			if (db_num_rows($q) > 0) return db_result($q, 0);
			// If no valid token is available, then try to refresh the token
			if ($this->refreshAccessToken($patient)) return $this->fhirAccessToken;
		}
		// If there is no token or refresh token available for this patient, then obtain token for ANY patient
		$token = $this->getAnyAccessToken();
		if ($token != "") return $token;
		// If there is no valid token for ANY patient, then obtain refresh token for ANY patient
		$refresh_token = $this->getAnyRefreshToken();
		if ($refresh_token != "") {			
			// Call FHIR service to fresh the token
			$this->fhirServices = new FhirServices($this->getFhirEndpointBaseUrl(), $GLOBALS['fhir_client_id'], $GLOBALS['fhir_client_secret']);
			$tokenInfo = $this->fhirServices->getAuthTokenViaRefreshToken($refresh_token);
			if (isset($tokenInfo->error)) return false;
			$this->fhirAccessToken = $tokenInfo->access_token;
			// Obtain the institution-specific MRN, if exists
			$institutionMrn = $this->getMrnByPatientId($tokenInfo->patient);
			// Update the access token on the table for whatever patient this belongs to
			$this->storeAccessToken($tokenInfo, $institutionMrn);
			// Return the token
			return $this->fhirAccessToken;
		}
		return false;
	}
	
	// Obtain a patient's refresh token from db table
	public function getRefreshToken($patient)
	{
		// Get value from table
		$sql = "select refresh_token from redcap_ehr_access_tokens where patient = '".db_escape($patient)."' 
				and refresh_token is not null and token_owner = '".db_escape($this->ehrUIID)."'";
		$q = db_query($sql);
		return (db_num_rows($q) > 0) ? db_result($q, 0) : "";
	}
	
	// Use a patient's refresh token to generate a new access token (because the existing access token has expired)
    public function refreshAccessToken($patient)
    {
		$refresh_token = $this->getRefreshToken($patient);
		if (!$refresh_token) return false;
		// Instantiate FHIR Services
		$this->fhirServices = new FhirServices($this->getFhirEndpointBaseUrl(), $GLOBALS['fhir_client_id'], $GLOBALS['fhir_client_secret']);
		// Call FHIR service to fresh the token
		$tokenInfo = $this->fhirServices->getAuthTokenViaRefreshToken($refresh_token);
		if (isset($tokenInfo->error)) return false;
		// Obtain the institution-specific MRN, if exists
		$institutionMrn = $this->getMrnByPatientId($patient);
		// Store the new token
		$this->storeAccessToken($tokenInfo, $institutionMrn);
		// Add token to object
		$this->fhirAccessToken = $tokenInfo->access_token;
		// Return true;
		return true;
	}
	
	// Delete an existing expired access token
	public function deleteExpiredAccessToken($token)
	{
		// Delete row from table
		$sql = "update redcap_ehr_access_tokens set access_token = null, refresh_token = null
				where access_token = '".db_escape($token)."' and token_owner = '".db_escape($this->ehrUIID)."'";
		return db_query($sql);
	}
	
	// Use a patient's ID to obtain the current refresh token from the tokens table
    public function getRefreshTokenByPatientId($patient_id)
    {
		$sql = "select refresh_token from redcap_ehr_access_tokens 
				where patient = '".db_escape($patient_id)."' and token_owner = '".db_escape($this->ehrUIID)."'";
		$q = db_query($sql);
		return (db_num_rows($q) > 0) ? db_result($q, 0) : null;
	}
	
	// Use a patient's ID to obtain the institution-specific MRN, if any, from the tokens table
    public function getMrnByPatientId($patient_id)
    {
		$sql = "select mrn from redcap_ehr_access_tokens 
				where patient = '".db_escape($patient_id)."' limit 1";
		$q = db_query($sql);
		return (db_num_rows($q) > 0) ? db_result($q, 0) : null;
	}
	
	// Obtain an array (pid=>array(attributes)) of the current user's registered projects
	private function setRegisteredProjects()
	{
		// Query projects
		$sql = "select p.project_id, if (u.role_id is null, u.record_create, (select ur.record_create from redcap_user_roles ur 
					where ur.role_id = u.role_id and ur.project_id = p.project_id)) as record_create, 
				p.auto_inc_set as record_auto_numbering, p.app_title, if (x.project_id is null, 0, 1) as has_mrn_field_type,
				p.realtime_webservice_enabled as ddp_enabled, 				
				if (p.realtime_webservice_enabled = '1', d2.record, d.record) as record,
				if (p.realtime_webservice_enabled = '1', r.item_count, null) as ddp_items
				from redcap_user_rights u, redcap_user_information i, redcap_ehr_user_projects e, redcap_projects p
				left join (select m.project_id, m.field_name from redcap_metadata m, redcap_validation_types v, redcap_user_rights u2, redcap_user_information i2 
					where v.data_type = 'mrn' and m.element_validation_type = v.validation_name and u2.project_id = m.project_id 
					and u2.username = i2.username and i2.ui_id = '".db_escape($this->ehrUIID)."') x on p.project_id = x.project_id
				left join redcap_data d on d.project_id = p.project_id and d.field_name = x.field_name 
					and d.value = '".db_escape($_SESSION['ehr-fhir']['patientInfo']['fhirPatientMRN'])."'
				left join redcap_ddp_mapping dm on dm.project_id = p.project_id and dm.is_record_identifier = 1
				left join redcap_data d2 on d2.project_id = p.project_id and d2.field_name = dm.field_name 
					and d2.value = '".db_escape($_SESSION['ehr-fhir']['patientInfo']['fhirPatientMRN'])."'				
				left join redcap_ddp_records r on r.project_id = p.project_id and r.record = d2.record
				where e.redcap_userid = i.ui_id and p.project_id = e.project_id and p.date_deleted is null 
					and u.project_id = p.project_id and u.username = i.username and i.ui_id = '".db_escape($this->ehrUIID)."'
					and p.status in (0, 1)
				order by p.project_id";
		$q = db_query($sql);
		while ($row = db_fetch_assoc($q)) {
			$pid = $row['project_id'];
			unset($row['project_id']);
			$row['app_title'] = strip_tags($row['app_title']);
			$this->registeredProjects[$pid] = $row;
		}
		return $projects;
	}
	
	// Obtain an array (pid=>title) of the current user's UNregistered projects.
	// Separate viable and non-viable projects in sub-arrays
	private function setUnegisteredProjects()
	{
		global $lang;
		$sql = "select p.project_id, p.app_title,
				if (x.project_id is null, p.realtime_webservice_enabled, 1) as viable
				from (redcap_user_rights u, redcap_user_information i, redcap_projects p)
				left join redcap_ehr_user_projects e on e.project_id = p.project_id and e.redcap_userid = i.ui_id
				left join (select m.project_id, m.field_name from redcap_metadata m, redcap_validation_types v, redcap_user_rights u2, redcap_user_information i2 
					where v.data_type = 'mrn' and m.element_validation_type = v.validation_name and u2.project_id = m.project_id 
					and u2.username = i2.username and i2.ui_id = '".db_escape($this->ehrUIID)."') x on p.project_id = x.project_id
				where p.date_deleted is null and u.project_id = p.project_id and u.username = i.username 
					and e.redcap_userid is null and i.ui_id = '".db_escape($this->ehrUIID)."' and p.status in (0, 1) 
				order by if (x.project_id is null, p.realtime_webservice_enabled, 1) desc, p.project_id";
		$q = db_query($sql);
		while ($row = db_fetch_assoc($q)) {
			$row['app_title'] = strip_tags($row['app_title']);
			$viableText = $row['viable'] ? $lang['data_entry_395'] : $lang['data_entry_396'];
			$this->unregisteredProjects[$viableText][$row['project_id']] = strip_tags($row['app_title']);
		}
		return $projects;
	}
	
	// Parse the FHIR data returned from a FHIR service and return it as a flattened array
    public function parseFhirData($data, $fieldsRequested=array())
    {
		// Place all flattened data into array
		$fhirArray = array();
		// If not find resource type, return
		if (!isset($data->resourceType)) return $fhirArray;
		// Parse FHIR bundle
		if ($data->resourceType == 'Bundle')
		{
			// Loop through all resources in the bundle
			foreach (array_keys($data->entry) as $entry_key) {
				// Skip if we can't find the correct structure
				if (!isset($data->entry[$entry_key]->resource)) continue;
				// Recursive call to parse individual resources in this bundle
				$fhirArray = array_merge($fhirArray, $this->parseFhirData($data->entry[$entry_key]->resource, $fieldsRequested));
			}			
		}
		// Parse patient demographics
		elseif ($data->resourceType == 'Patient')
		{
			if (in_array('gender', $fieldsRequested)) {
				$fhirArray[] = array('field'=>'gender', 'value'=>$data->gender, 'timestamp'=>null);
			}
			if (in_array('birthDate', $fieldsRequested)) {
				$fhirArray[] = array('field'=>'birthDate', 'value'=>$data->birthDate, 'timestamp'=>null);
			}
			foreach ($data->name as $attr) {
				$nameFields = array('given', 'family');
				if ($attr->use == "usual" || $attr->use == "official") {
					foreach ($nameFields as $nameField) {
						if (in_array('name-'.$nameField, $fieldsRequested)) {
							$fhirArray[] = array('field'=>'name-'.$nameField, 'value'=>($nameField == 'given' ? $attr->given[0] : $attr->family[0]), 'timestamp'=>null);
						}
					}
				}
			}
			foreach ($data->address as $attr) {
				$addressFields = array('line', 'city', 'state', 'postalCode', 'country');
				if ($attr->use == "home") {
					foreach ($addressFields as $addressField) {
						if (in_array('address-'.$addressField, $fieldsRequested)) {
							if ($addressField == 'line' && is_array($attr->$addressField)) {
								$attr->$addressField = implode(", ", $attr->$addressField);
							}
							$fhirArray[] = array('field'=>'address-'.$addressField, 'value'=>$attr->$addressField, 'timestamp'=>null);
						}
					}
				}
			}
			foreach ($data->telecom as $attr) {
				if (isset($attr->value) && $attr->value != '') {
					if ($attr->system == "phone" && ($attr->use == "home" || $attr->use == "mobile")
						&& (!isset($attr->period) || (isset($attr->period) && !isset($attr->period->end)))) 
					{
						if ($attr->use == "home" && in_array('phone-home', $fieldsRequested)) {
							$fhirArray[] = array('field'=>'phone-home', 'value'=>$attr->value, 'timestamp'=>null);
						} elseif ($attr->use == "mobile" && in_array('phone-mobile', $fieldsRequested)) {
							$fhirArray[] = array('field'=>'phone-mobile', 'value'=>$attr->value, 'timestamp'=>null);
						}
					}
					elseif ($attr->system == "email") {
						$fhirArray[] = array('field'=>'email', 'value'=>$attr->value, 'timestamp'=>null);
					}
				}
			}
		}
		// Parse active medications list
		elseif ($data->resourceType == 'MedicationOrder')
		{
			$targetField = 'active-medications-list';
			// Loop through codings
			$codeDisplay = "";
			if (isset($data->medicationCodeableConcept->text)) {
				if ($codeDisplay != "") $codeDisplay .= ", ";
				$codeDisplay .= $data->medicationCodeableConcept->text;
			}
			if (isset($data->medicationReference->display)) {
				if ($codeDisplay != "") $codeDisplay .= ", ";
				$codeDisplay .= $data->medicationReference->display;
			}
			if (isset($data->dosageInstruction[0]->text)) {
				if ($codeDisplay != "") $codeDisplay .= ", ";
				$codeDisplay .= $data->dosageInstruction[0]->text;
			}
			if (isset($data->dateWritten)) {
				if ($codeDisplay != "") $codeDisplay .= ", ";
				$codeDisplay .= $data->dateWritten;
			}
			$codeDisplay = trim($codeDisplay);
			// Add to field data array
			if ($codeDisplay != "") {
				$this->fhirDataMeds .= ($this->fhirDataMeds == "" ? "" : "\n-----\n") . $codeDisplay;
				$fhirArray[$targetField] = array('field'=>$targetField, 'value'=>$this->fhirDataMeds, 'timestamp'=>null);
			}
		}
		// Parse "Condition" data for "Problem list and health concerns"
		elseif ($data->resourceType == 'Condition')
		{
			$targetField = 'problem-list';
			// Loop through codings
			$codeDisplay = $codeDisplayStandard = "";
			foreach ($data->code->coding as $thisCode) {
				// Look for specific coding matches (loinc, snomed)
				// if (stripos($thisCode->system, 'loinc')) {
					// $codeDisplay = $codeDisplayStandard = "{$thisCode->display} (LOINC {$thisCode->code}) - {$data->dateRecorded}";
				// } elseif (stripos($thisCode->system, 'snomed')) {
					// $codeDisplay = $codeDisplayStandard = "{$thisCode->display} (SNOMED {$thisCode->code}) - {$data->dateRecorded}";
				if (stripos($thisCode->system, 'loinc') || stripos($thisCode->system, 'snomed')) {
					$codeDisplay = $codeDisplayStandard = "{$thisCode->display}, {$data->dateRecorded}";
				} else {
					$codeDisplay = "{$thisCode->display}, {$data->dateRecorded}";
				}
			}
			// Use a standard if we have one
			$codeDisplay = ($codeDisplayStandard == "") ? $codeDisplay : $codeDisplayStandard;
			$codeDisplay = trim($codeDisplay);
			// Add to field data array
			if ($codeDisplay != "") {
				$this->fhirDataConditions .= ($this->fhirDataConditions == "" ? "" : "\n-----\n") . $codeDisplay;
				$fhirArray[$targetField] = array('field'=>$targetField, 'value'=>$this->fhirDataConditions, 'timestamp'=>null);
			}
		}
		// Parse non-demographics resources (e.g., Observation)
		elseif ($this->getFhirDataResourceCodeStructureName($data) !== false)
		{
			// Determine the "code" sub-structure name based on the FHIR endpoint category
			$codeStructureAttr = $this->getFhirDataResourceCodeStructureName($data);
			// Loop through all codings that are returned
			foreach (array_keys($data->$codeStructureAttr->coding) as $coding_key) {
				// Skip if we can't find the correct structure
				if (!isset($data->$codeStructureAttr->coding[$coding_key]->code) || !isset($data->valueQuantity->value)) continue;
				// Field
				$field = $data->$codeStructureAttr->coding[$coding_key]->code;
				// Value
				$value = $data->valueQuantity->value;
				// Timestamp
				$timestamp = null;
				if (isset($this->fhirEndpointDateAttribute[$data->resourceType])) {
					$dateAttr = $this->fhirEndpointDateAttribute[$data->resourceType];
					if (isset($data->$dateAttr)) {
						$timestamp = $this->cleanTimestamp($data->$dateAttr);
					}
				}
				// Check if the code matches a code we're looking for (from $fieldsRequested parameter)				
				if (!in_array($field, $fieldsRequested)) continue;
				// Add data value and timestamp
				$fhirArray[] = array('field'=>$field, 'value'=>$value, 'timestamp'=>$timestamp);
			}
		}
		// Return flattened data in array
		return $fhirArray;
	}
	
	// Map the FHIR endpoint category to the name of the "code" sub-structure in the resulting FHIR data bundle.
	private function getFhirDataResourceCodeStructureName(&$data)
	{
		if (isset($this->fhirDataResourceCodeStructureName[$data->resourceType])) {
			$structureName = $this->fhirDataResourceCodeStructureName[$data->resourceType];
			if (isset($data->$structureName)) {
				return $structureName;
			}
		}
		return false;
	}	
	
	// Clean a timestamp so that it only consists of numerals, spaces, dashes, and colons
	private function cleanTimestamp($timestamp)
	{
		return trim(preg_replace("/[^0-9-_: ]/", " ", $timestamp));
	}
}
